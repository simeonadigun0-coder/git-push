# 🗳️ Election Voting Portal — GitHub + Vercel

A secure, token-based voting system. Voters get unique one-time codes; the admin manages candidates, codes, and live results.

---

## 📁 Project Structure

```
voting-system/
├── index.html          ← Frontend (the full voting portal UI)
├── api/
│   └── vote.js         ← Vercel serverless API (replaces Google Apps Script)
├── package.json
├── vercel.json
└── README.md
```

---

## 🚀 Deployment: Step-by-Step

### Step 1 — Push to GitHub

1. Go to [github.com](https://github.com) → **New repository**
2. Name it `voting-system` (or anything you like), set it to **Private**
3. On your computer, open a terminal in this folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/voting-system.git
git push -u origin main
```

---

### Step 2 — Create a Vercel Project

1. Go to [vercel.com](https://vercel.com) → **Add New Project**
2. Click **Import Git Repository** → select your `voting-system` repo
3. Leave all build settings as default (no framework, no build command)
4. Click **Deploy** — Vercel will deploy it immediately

---

### Step 3 — Add Vercel KV (Database)

The API stores all votes, tokens, and config in **Vercel KV** (Redis).

1. In your Vercel project dashboard → **Storage** tab
2. Click **Create Database** → choose **KV**
3. Name it `voting-kv`, click **Create**
4. Click **Connect to Project** → select your project → **Connect**

Vercel automatically adds `KV_REST_API_URL` and `KV_REST_API_TOKEN` to your environment variables.

---

### Step 4 — Set Your Admin Password

1. In your Vercel project → **Settings** → **Environment Variables**
2. Add a new variable:
   - **Key:** `ADMIN_PASSWORD`
   - **Value:** your chosen password (e.g. `Morgan123`)
3. Click **Save**
4. Go back to **Deployments** → click **Redeploy** (so the new env var takes effect)

---

### Step 5 — Done! 🎉

Visit your Vercel URL (e.g. `https://voting-system-abc.vercel.app`).

- **Voters** click "I want to Vote" → enter their code
- **Admin** clicks "Admin Login" → enter your password → manage everything

---

## ⚙️ Admin Guide

| Tab | What you can do |
|-----|----------------|
| **Setup** | Set the poll title, add/remove contestants and positions |
| **Codes** | Generate voter codes, copy/share individual links via WhatsApp, delete unused codes |
| **Results** | Live vote tally with progress bars, reset all data |

---

## 🔒 Security Notes

- Each voter code is single-use — once voted, it cannot be reused
- The admin password is stored as a Vercel environment variable (never in code)
- All API calls go to your own serverless function — no third-party services

---

## 🛠️ Changing the Admin Password Later

1. Vercel dashboard → **Settings** → **Environment Variables**
2. Edit `ADMIN_PASSWORD`
3. Redeploy

---

## 🔄 Making Updates

Edit files locally, then:

```bash
git add .
git commit -m "Update"
git push
```

Vercel auto-deploys on every push to `main`.
