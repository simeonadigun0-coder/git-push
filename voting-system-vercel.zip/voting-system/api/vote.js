// ============================================================
//  VOTING SYSTEM — Vercel Serverless API
//  Replaces Google Apps Script backend
//
//  Storage: Vercel KV (Redis)
//  Set these env vars in your Vercel project dashboard:
//    KV_REST_API_URL      (auto-set when you add a KV store)
//    KV_REST_API_TOKEN    (auto-set when you add a KV store)
//    ADMIN_PASSWORD       (set this yourself, e.g. Morgan123)
// ============================================================

import { kv } from '@vercel/kv';

// ── CORS headers ──────────────────────────────────────────────
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS },
  });
}

// ── Auth ──────────────────────────────────────────────────────
function checkPw(pw) {
  return pw === (process.env.ADMIN_PASSWORD || 'Morgan123');
}

// ── Token generator ───────────────────────────────────────────
function genToken() {
  const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let t = '';
  for (let i = 0; i < 8; i++) {
    if (i === 4) t += '-';
    t += ch[Math.floor(Math.random() * ch.length)];
  }
  return t;
}

// ── Storage helpers ───────────────────────────────────────────
async function getConfig() {
  return (await kv.get('poll_config')) || { pollTitle: '', contestants: [] };
}
async function setConfig(c) { await kv.set('poll_config', c); }

async function getTokens() {
  return (await kv.get('poll_tokens')) || {};
}
async function setTokens(t) { await kv.set('poll_tokens', t); }

async function getVotes() {
  return (await kv.get('poll_votes')) || {};
}
async function setVotes(v) { await kv.set('poll_votes', v); }

// ── API Actions ───────────────────────────────────────────────
async function apiGetConfig() {
  const cfg = await getConfig();
  return { ok: true, pollTitle: cfg.pollTitle, contestants: cfg.contestants };
}

async function apiValidate(rawToken) {
  const token = (rawToken || '').replace(/[^\w-]/g, '').toUpperCase();
  if (!token) return { ok: false, error: 'No voter code provided.' };

  const tokens = await getTokens();
  const cfg    = await getConfig();

  if (!tokens[token])      return { ok: false, error: 'Invalid voter code. Please check and try again.' };
  if (tokens[token].used)  return { ok: false, error: 'This voter code has already been used.' };
  if (!cfg.contestants || !cfg.contestants.length)
    return { ok: false, error: 'The poll has not been set up yet.' };

  return { ok: true, token, pollTitle: cfg.pollTitle, contestants: cfg.contestants };
}

async function apiVote(rawToken, votesJson) {
  const token = (rawToken || '').replace(/[^\w-]/g, '').toUpperCase();
  if (!token) return { ok: false, error: 'Missing token.' };

  let votesMap;
  try { votesMap = JSON.parse(decodeURIComponent(votesJson || '{}')); }
  catch { return { ok: false, error: 'Invalid vote data.' }; }

  if (!Object.keys(votesMap).length) return { ok: false, error: 'No votes submitted.' };

  const tokens = await getTokens();
  if (!tokens[token])      return { ok: false, error: 'Invalid voter code.' };
  if (tokens[token].used)  return { ok: false, error: 'This code has already been used.' };

  const cfg        = await getConfig();
  const validNames = (cfg.contestants || []).map(c => c.name);
  for (const [, name] of Object.entries(votesMap)) {
    if (!validNames.includes(name))
      return { ok: false, error: 'Invalid contestant: ' + name };
  }

  tokens[token] = { used: true, votedFor: votesMap, ts: new Date().toISOString() };
  await setTokens(tokens);

  const votes = await getVotes();
  for (const name of Object.values(votesMap)) {
    votes[name] = (votes[name] || 0) + 1;
  }
  await setVotes(votes);

  return { ok: true, votedFor: votesMap };
}

async function apiAdminLogin(pw) {
  return { ok: checkPw(pw) };
}

async function apiAdminData(pw) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  const [config, tokens, votes] = await Promise.all([getConfig(), getTokens(), getVotes()]);
  return { ok: true, config, tokens, votes };
}

async function apiSaveConfig(pw, configJson) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  let cfg;
  try { cfg = JSON.parse(decodeURIComponent(configJson)); }
  catch { return { ok: false, error: 'Invalid config JSON.' }; }
  await setConfig(cfg);
  return { ok: true };
}

async function apiGenTokens(pw, count) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  const tokens    = await getTokens();
  const newTokens = [];
  for (let i = 0; i < Math.min(count, 200); i++) {
    let t;
    do { t = genToken(); } while (tokens[t]);
    tokens[t] = { used: false, votedFor: null };
    newTokens.push(t);
  }
  await setTokens(tokens);
  return { ok: true, newTokens };
}

async function apiDeleteUnused(pw) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  const tokens = await getTokens();
  for (const k of Object.keys(tokens)) {
    if (!tokens[k].used) delete tokens[k];
  }
  await setTokens(tokens);
  return { ok: true };
}

async function apiReset(pw) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  await Promise.all([
    kv.del('poll_config'),
    kv.del('poll_tokens'),
    kv.del('poll_votes'),
  ]);
  return { ok: true };
}

// ── Main handler ──────────────────────────────────────────────
export default async function handler(req) {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS });
  }

  const url    = new URL(req.url);
  const p      = Object.fromEntries(url.searchParams.entries());
  const action = p.action || '';

  try {
    let result;
    switch (action) {
      case 'config':       result = await apiGetConfig();                                  break;
      case 'validate':     result = await apiValidate(p.token);                            break;
      case 'vote':         result = await apiVote(p.token, p.votes);                       break;
      case 'adminLogin':   result = await apiAdminLogin(p.pw);                             break;
      case 'adminData':    result = await apiAdminData(p.pw);                              break;
      case 'saveConfig':   result = await apiSaveConfig(p.pw, p.config);                  break;
      case 'genTokens':    result = await apiGenTokens(p.pw, parseInt(p.count) || 10);    break;
      case 'deleteUnused': result = await apiDeleteUnused(p.pw);                           break;
      case 'reset':        result = await apiReset(p.pw);                                 break;
      default:             result = { ok: true, msg: 'Voting API running.' };
    }
    return json(result);
  } catch (err) {
    console.error('API error:', err);
    return json({ ok: false, error: 'Server error: ' + err.message }, 500);
  }
}

export const config = {
  runtime: 'edge',
};
