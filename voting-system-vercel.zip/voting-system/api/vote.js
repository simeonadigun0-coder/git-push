// ============================================================
//  VOTING SYSTEM — Vercel Serverless API
//  Storage: Vercel KV (Redis)
//  Env vars to set in Vercel dashboard:
//    KV_REST_API_URL    (auto-added when you create a KV store)
//    KV_REST_API_TOKEN  (auto-added when you create a KV store)
//    ADMIN_PASSWORD     (set this yourself)
// ============================================================

const { createClient } = require('@vercel/kv');

// ── KV client ─────────────────────────────────────────────────
function getKV() {
  return createClient({
    url:   process.env.KV_REST_API_URL,
    token: process.env.KV_REST_API_TOKEN,
  });
}

// ── CORS headers ──────────────────────────────────────────────
function respond(res, data, status = 200) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');
  res.status(status).json(data);
}

// ── Auth ──────────────────────────────────────────────────────
function checkPw(pw) {
  return pw === (process.env.ADMIN_PASSWORD || 'Morgan123');
}

// ── Token generator ───────────────────────────────────────────
function genToken() {
  const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let t = '';
  for (let i = 0; i < 8; i++) {
    if (i === 4) t += '-';
    t += ch[Math.floor(Math.random() * ch.length)];
  }
  return t;
}

// ── Storage helpers ───────────────────────────────────────────
async function getConfig(kv) {
  return (await kv.get('poll_config')) || { pollTitle: '', contestants: [] };
}
async function setConfig(kv, c) { await kv.set('poll_config', c); }

async function getTokens(kv) {
  return (await kv.get('poll_tokens')) || {};
}
async function setTokens(kv, t) { await kv.set('poll_tokens', t); }

async function getVotes(kv) {
  return (await kv.get('poll_votes')) || {};
}
async function setVotes(kv, v) { await kv.set('poll_votes', v); }

// ── API Actions ───────────────────────────────────────────────
async function apiGetConfig(kv) {
  const cfg = await getConfig(kv);
  return { ok: true, pollTitle: cfg.pollTitle, contestants: cfg.contestants };
}

async function apiValidate(kv, rawToken) {
  const token = (rawToken || '').replace(/[^\w-]/g, '').toUpperCase();
  if (!token) return { ok: false, error: 'No voter code provided.' };

  const tokens = await getTokens(kv);
  const cfg    = await getConfig(kv);

  if (!tokens[token])      return { ok: false, error: 'Invalid voter code. Please check and try again.' };
  if (tokens[token].used)  return { ok: false, error: 'This voter code has already been used.' };
  if (!cfg.contestants || !cfg.contestants.length)
    return { ok: false, error: 'The poll has not been set up yet.' };

  return { ok: true, token, pollTitle: cfg.pollTitle, contestants: cfg.contestants };
}

async function apiVote(kv, rawToken, votesJson) {
  const token = (rawToken || '').replace(/[^\w-]/g, '').toUpperCase();
  if (!token) return { ok: false, error: 'Missing token.' };

  let votesMap;
  try { votesMap = JSON.parse(decodeURIComponent(votesJson || '{}')); }
  catch (e) { return { ok: false, error: 'Invalid vote data.' }; }

  if (!Object.keys(votesMap).length) return { ok: false, error: 'No votes submitted.' };

  const tokens = await getTokens(kv);
  if (!tokens[token])      return { ok: false, error: 'Invalid voter code.' };
  if (tokens[token].used)  return { ok: false, error: 'This code has already been used.' };

  const cfg        = await getConfig(kv);
  const validNames = (cfg.contestants || []).map(c => c.name);
  for (const name of Object.values(votesMap)) {
    if (!validNames.includes(name))
      return { ok: false, error: 'Invalid contestant: ' + name };
  }

  tokens[token] = { used: true, votedFor: votesMap, ts: new Date().toISOString() };
  await setTokens(kv, tokens);

  const votes = await getVotes(kv);
  for (const name of Object.values(votesMap)) {
    votes[name] = (votes[name] || 0) + 1;
  }
  await setVotes(kv, votes);

  return { ok: true, votedFor: votesMap };
}

async function apiAdminLogin(pw) {
  return { ok: checkPw(pw) };
}

async function apiAdminData(kv, pw) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  const [config, tokens, votes] = await Promise.all([
    getConfig(kv), getTokens(kv), getVotes(kv)
  ]);
  return { ok: true, config, tokens, votes };
}

async function apiSaveConfig(kv, pw, configJson) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  let cfg;
  try { cfg = JSON.parse(decodeURIComponent(configJson)); }
  catch (e) { return { ok: false, error: 'Invalid config JSON.' }; }
  await setConfig(kv, cfg);
  return { ok: true };
}

async function apiGenTokens(kv, pw, count) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  const tokens    = await getTokens(kv);
  const newTokens = [];
  for (let i = 0; i < Math.min(count, 200); i++) {
    let t;
    do { t = genToken(); } while (tokens[t]);
    tokens[t] = { used: false, votedFor: null };
    newTokens.push(t);
  }
  await setTokens(kv, tokens);
  return { ok: true, newTokens };
}

async function apiDeleteUnused(kv, pw) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  const tokens = await getTokens(kv);
  for (const k of Object.keys(tokens)) {
    if (!tokens[k].used) delete tokens[k];
  }
  await setTokens(kv, tokens);
  return { ok: true };
}

async function apiReset(kv, pw) {
  if (!checkPw(pw)) return { ok: false, error: 'Wrong password.' };
  await Promise.all([
    kv.del('poll_config'),
    kv.del('poll_tokens'),
    kv.del('poll_votes'),
  ]);
  return { ok: true };
}

// ── Main handler ──────────────────────────────────────────────
module.exports = async function handler(req, res) {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin',  '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(204).end();
  }

  const p      = req.query || {};
  const action = p.action || '';

  // Check KV is configured
  if (!process.env.KV_REST_API_URL || !process.env.KV_REST_API_TOKEN) {
    return respond(res, {
      ok: false,
      error: 'Database not connected. Please add a Vercel KV store and set KV_REST_API_URL + KV_REST_API_TOKEN in your project environment variables, then redeploy.'
    }, 500);
  }

  const kv = getKV();

  try {
    let result;
    switch (action) {
      case 'config':       result = await apiGetConfig(kv);                                   break;
      case 'validate':     result = await apiValidate(kv, p.token);                           break;
      case 'vote':         result = await apiVote(kv, p.token, p.votes);                      break;
      case 'adminLogin':   result = await apiAdminLogin(p.pw);                                break;
      case 'adminData':    result = await apiAdminData(kv, p.pw);                             break;
      case 'saveConfig':   result = await apiSaveConfig(kv, p.pw, p.config);                 break;
      case 'genTokens':    result = await apiGenTokens(kv, p.pw, parseInt(p.count) || 10);   break;
      case 'deleteUnused': result = await apiDeleteUnused(kv, p.pw);                          break;
      case 'reset':        result = await apiReset(kv, p.pw);                                break;
      default:             result = { ok: true, msg: 'Voting API is running.' };
    }
    return respond(res, result);
  } catch (err) {
    console.error('API error:', err);
    return respond(res, { ok: false, error: 'Server error: ' + err.message }, 500);
  }
};
